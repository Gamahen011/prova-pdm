import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { IonicModule } from '@ionic/angular';
import { Produto } from '../models/produto';
import { AuthService } from '../services/authService';
import { produtoService } from '../services/produtoService';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, FormsModule],
})
export class HomePage implements OnInit {

  produtos: Produto[] = [];
  textoNovo = '';
  mensagemErro = '';

  constructor(
    public auth: AuthService,
    private produtoService: produtoService,
    private router: Router,
  ) {}

  async ngOnInit() {
    const usuario = await this.auth.esperarUsuario();
    if (!usuario) {
      this.router.navigate(['/login']);
      return;
    }
    await this.carregar();
  }

  async carregar() {
    this.produtos = await this.produtoService.listar();
  }

  async publicar() {
    this.mensagemErro = '';

    if (!this.textoNovo.trim()) {
      this.mensagemErro = 'Escreva um recado antes de publicar.';
      return;
    }

    // nome do Google > e-mail > anônimo — nessa ordem
    const autor = this.auth.usuario?.displayName
      ?? this.auth.usuario?.email
      ?? 'anônimo';

    await this.produtoService.adicionar(this.textoNovo.trim(), autor);
    this.textoNovo = '';
    await this.carregar();
  }
  
  async excluir(id: string) {
    await this.produtoService.remover(id);
    await this.carregar();
  }

  async sair() {
    await this.auth.sair();
    this.router.navigate(['/login']);
  }

  
}