import { Injectable } from '@angular/core';
import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  getDocs,
  orderBy,
  query,
  Timestamp,
} from 'firebase/firestore';
import { db } from '../firebase.config';
import { Produto } from '../models/produto';

@Injectable({ providedIn: 'root' })
export class produtoService {

  produtos:  Produto[] = [
    { id: 1, nome: 'Porção de batata', preco: 35, doce: false, esgotado: false, ultimasunidades: false },
    { id: 2, nome: 'Brigadeiro', preco: 20, doce: true, esgotado: false, ultimasunidades: false },
    { id: 3, nome: 'Pudim de leite', preco: 15, doce: true, esgotado: false, ultimasunidades: false }  
  ];

  async listar(): Promise<Produto[]> {
    const consulta = query(collection(db, 'produtos'), orderBy('id'));
    const snap = await getDocs(consulta);

    return snap.docs.map((item) => {
      const dados = item.data();
      return {
        id: item.id,
        nome: dados['nome'],
        preco: dados['preco'],
        doce: dados['doce'],
        esgotado: dados['esgotado'],
        ultimasunidades: dados['ultimasunidades']
      };
      
    });
  }

  adicionar(texto: string, autor: string) {
    return addDoc(collection(db, 'produtos'), {
      texto,
      autor,
      criadoEm: Timestamp.now(),
    });
  }

  remover(id: string) {
    return deleteDoc(doc(db, 'produtos', id));
  }

}